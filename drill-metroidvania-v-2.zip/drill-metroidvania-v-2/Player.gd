class_name Player extends CharacterBody2D


var moveSpeed :float= 800.0
var jumpStrength :float= -1400.0
var moveVelocity:Vector2=Vector2(0,0)
var drillVelocity:Vector2=Vector2(0,0)
var knockbackVelocity:Vector2=Vector2(0,0)
var isBall:bool=false
var canDrill:bool=false
var mode:String="Normal"
var ballSize:float=1.5
var drillDirection:Vector2
@onready var explosion:=preload("res://Explosion.tscn")
func _physics_process(delta: float) -> void:
	$Area2D.visible=mode=="Ball"
	$Polygon2D.visible=mode=="Normal"
	drillDirection=Vector2(Input.get_axis("Left","Right"),Input.get_axis("ui_up","ui_down"))
	$Area2D/Node2D.visible=(drillDirection.length()>0)
	if mode=="Ball":
		$Area2D/Node2D.rotation=Vector2.ZERO.angle_to_point(drillDirection)
		ballSize-=delta
		$Area2D/Line2D.scale=Vector2(min(ballSize,1),min(1,ballSize))
		if ballSize<=0:
			switch_mode("Normal")
		
	else:
		ballSize=1.8
	if not is_on_floor() and Input.is_action_pressed("Jump") and velocity.y<=0 and mode=="Normal":
		moveVelocity += get_gravity() * delta*4.5
	elif not is_on_floor() and mode=="Normal":
		moveVelocity += get_gravity() * delta*7
	
	if Input.is_action_just_pressed("Jump") and is_on_floor() and mode=="Normal":
		moveVelocity.y = jumpStrength
	moveVelocity.y=min(moveVelocity.y,2400)
	if is_on_ceiling():
		moveVelocity.y=max(0,moveVelocity.y)
		knockbackVelocity.y=max(0,knockbackVelocity.y)
		drillVelocity.y=max(0,drillVelocity.y)
	if is_on_floor():
		moveVelocity.y=min(0,moveVelocity.y)
		knockbackVelocity.y=min(0,knockbackVelocity.y)
		drillVelocity.y=min(0,drillVelocity.y)
	var direction := Input.get_axis("Left", "Right")
	if mode=="Normal":
		moveVelocity.x = direction * moveSpeed
	else:
		moveVelocity.x*=0
	if Input.is_action_just_pressed("X"):
		if mode=="Normal":
			mode="Ball"
			$CollisionShape2D.disabled=true
			
		elif mode=="Ball":
			if !drillDirection or !canDrill:
				switch_mode("Normal")
			else:
				mode="Drill"
	if mode=="Normal":
		velocity=moveVelocity+knockbackVelocity
	elif mode=="Ball":
		velocity*=0
	elif mode=="Drill":
		velocity=drillVelocity
	move_and_slide()

func switch_mode(newMode):
	if newMode=="Ball":
			mode="Ball"
			$CollisionShape2D.disabled=true
	elif newMode=="Normal":
		if mode=="Ball":

			var newExplosion:=explosion.instantiate()
			get_tree().current_scene.add_child(newExplosion)
			newExplosion.position=position
			mode="Normal"
			$CollisionShape2D.disabled=false
