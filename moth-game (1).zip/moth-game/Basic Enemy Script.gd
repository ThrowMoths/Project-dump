extends CharacterBody2D


@export var SPEED = 5*00.0
const JUMP_VELOCITY = -400.0
@export var maxHealth:=5.0
var Health := 5.0
var curse:=0.0
var Player = null
var TargetPos = Vector2.ZERO
var Direction = 1
var RaycastRange = 1000
var contamination:=0.0
var contaminationLevel:=0
var contaminationTime:=1.0
var cureTimer:=1.0
var shock:=0
var moveVelocity:=Vector2(0,0)
var knockbackVelocity:=Vector2(0,0)
@export var contactDamage:=2.0
@export var knockbackMulti:=1.0
signal death
var deathEmitted:=false
signal hit
@onready var curseWave:=preload("res://Curse Wave.tscn")
@export var flying:=false

func _ready() -> void:
	Health=maxHealth

func contaminationDamage():
	take_damage(floor(contaminationLevel)*0.1)


func _physics_process(delta: float) -> void:

	contamination-=delta*(floor(contamination)+1)*0.5
	cureTimer-=delta*(1+contaminationLevel)*0.3
	if cureTimer<=0:
		cureTimer=1.0
		contaminationLevel=max(0,contaminationLevel-1)
	
	if contaminationLevel>0:
		$"Contamination Level".visible=true
		$"Contamination Level/RichTextLabel".text=str(contaminationLevel)
		contaminationTime-=delta*(contaminationLevel+1)
		if contaminationTime<=0:
			contaminationTime=1
			contaminationDamage()
	else:$"Contamination Level".visible=false
		

	$"Health Outline/Health Lerp".set_point_position(1,Vector2(lerp($"Health Outline/Health Lerp".get_point_position(1).x, -100+Health/maxHealth*200,3*delta),-160))
	modulate=lerp(modulate,Color(1,1,1),delta*2)
	
	
	
	if not is_on_floor() and !flying:
		moveVelocity += get_gravity() * delta * 5
	
	
	
	Player = get_tree().current_scene.Player
	
	$Polygon2D.scale.x = Direction
	$RayCast2D.target_position.x = Direction * RaycastRange
	
	Direction = sign(Player.position.x - position.x)
	
	#moveVelocity.x =(Direction * SPEED*(1-0.15*contaminationLevel))
	velocity=knockbackVelocity+moveVelocity
	knockbackVelocity= knockbackVelocity.move_toward(Vector2(0,0),3500*delta)
	
	
	move_and_slide()
	
	
	
	

func take_damage(Damage):
	Health -= Damage
	print(Damage)
	emit_signal("hit")
	if Health <= 0:
		Player.enemiesKilled+=1
		
		get_tree().current_scene.enemyList.erase(self)
		call_deferred("queue_free")
		if !deathEmitted:
			deathEmitted=true
			emit_signal("death")
		
	modulate=Color(1,0,0)
	
	$"Health Outline/Health".set_point_position(1,Vector2(-100+Health/maxHealth*200,-160))
func take_knockback(vector):
	knockbackVelocity=vector*knockbackMulti
	moveVelocity.y =move_toward(moveVelocity.y,vector.y*knockbackMulti,vector.length()*knockbackMulti)

func take_curse(curseDamage):
	curse+=curseDamage
	$"Health Outline/Curse".set_point_position(1,Vector2(-100+curse/maxHealth*200,-160))
	if curse>Health:
		explode()

func explode():
	var newWave:=curseWave.instantiate()
	get_tree().current_scene.call_deferred("add_child",newWave)
	newWave.maxSize=curse/1.6
	newWave.position=position
	call_deferred("queue_free")

func add_contaminate(damage):
	contamination+=(damage)
	while contamination>1+0.5*contaminationLevel:
		contamination-=1+0.5*contaminationLevel
		contaminationLevel=min(4,contaminationLevel+1)
		cureTimer=1.0
