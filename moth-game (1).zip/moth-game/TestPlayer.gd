extends CharacterBody2D

var lastDirection:=1.0

const SPEED = 900.0
const JUMP_VELOCITY = -1000.0


var knockbackVelocity:=Vector2(0,0)
var moveVelocity:=Vector2(0,0)

var currWeapon:="Fish"
var magicAbility:="None"
var starCount:=3
var stars:=[]

var maxAttackCooldown:=0.3
var maxAttackAbilityCooldown:=0.01
var attackCooldown:=0.05
var attackAbilityCooldown:=0.05
var arrowCharge:=0.0
var arrowCharging:=false
var arrowAiming:=false
var reloadTimer:=0.5
var revolverAmmo:=6.0
var longReloading:=0.0
var weaponCooldownTimes:={"Fish":0.1,"Star":0.5,"Bat":0.6,"Arrow":0.2,"Flamethrower":0.02,"Revolver":0.3}
var weaponAbilityCooldownTimes:={"Fish":2,"Star":0.8,"Bat":1.0,"Arrow":0,"Flamethrower":0.01,"Revolver":1}
var health:=10.0
var maxHealth:=10.0
var invincible:=false
var invincibilityTime:=0.5

#Arrow Upgrade variables
var sentryTime:=0.0
var enemiesKilled=0

@onready var star:=preload("res://Star Bullet.tscn")
@onready var ball:=preload("res://Baseball.tscn")
@onready var batSwing:=preload("res://Bat Swing.tscn")

@onready var arrow:=preload("res://Arrow.tscn")
@onready var bowLaser:=preload("res://Bow Laser.tscn")

@onready var fuel:=preload("res://Fire Extinguisher.tscn")
@onready var flame:=preload("res://Flame.tscn")
@onready var bullet:=preload("res://Bullet.tscn")
@onready var fish:=preload("res://fish.tscn")
@onready var fishBait:=preload("res://Fish Bait.tscn")

var weapons:=["Star","Bat","Arrow","Flamethrower","Revolver","Fish"]
@onready var firePoint:=$"FirePoint/Arrow Sprite"
var currWeaponIndex:=0

func switch_weapon(weapon):
	if weapon!=currWeapon:
		match currWeapon:
			"Star":
				get_tree().call_group("Star","free")
			"Bat":
				pass
			"Arrow":
				arrowAiming=false
				moveVelocity.y=0
				enemiesKilled=0
			"Flamethrower":
				pass
			"Revolver":
				pass
			"Fish":
				get_tree().call_group("Fish","free")
				get_tree().call_group("Bait","free")
	
	currWeapon=weapon
func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("1"):
		switch_weapon(weapons[0])
	elif Input.is_action_just_pressed("2"):
		switch_weapon(weapons[1])
	elif Input.is_action_just_pressed("3"):
		switch_weapon(weapons[2])
	elif Input.is_action_just_pressed("4"):
		switch_weapon(weapons[3])
	elif Input.is_action_just_pressed("5"):
		switch_weapon(weapons[4])
	elif Input.is_action_just_pressed("6"):
		switch_weapon(weapons[5])
	elif Input.is_action_just_pressed("Q"):
		currWeaponIndex=(currWeaponIndex-1)%6
		switch_weapon(weapons[currWeaponIndex])
	elif Input.is_action_just_pressed("E"):
		currWeaponIndex=(currWeaponIndex+1)%6
		switch_weapon(weapons[currWeaponIndex])

func _physics_process(delta: float) -> void:
	$"Aiming icon".visible=arrowAiming
	sentryTime=min(sentryTime+delta,5)
	
	invincible=invincibilityTime>0
	if invincibilityTime>=0:
		self_modulate.a= 10*invincibilityTime-floor(invincibilityTime*10)
	else:
		self_modulate.a=1
	invincibilityTime-=delta
	$"Revolver Ammo Indicator".visible=currWeapon=="Revolver"
	$FirePoint/Canvas.scale.y=0.2-0.4*int(get_local_mouse_position().x>0)
	$FirePoint/Canvas.visible=currWeapon=="Revolver"
	
	$"Arrow Charge Indicator".visible=currWeapon=="Arrow"
	$"FirePoint/Arrow Sprite".visible=currWeapon=="Arrow"
	
	if longReloading<=revolverAmmo and reloadTimer<=0.3:
		longReloading=-1
	
	$FirePoint.look_at(get_global_mouse_position())
	$Line2D2.visible=arrowCharge>0
	attackCooldown-=delta
	attackAbilityCooldown-=delta
	
	reloadTimer-=delta
	if reloadTimer<=0:
		revolverAmmo=min(revolverAmmo+delta*2*(1-0*int(longReloading>0)),6)
	
	var chargeSpeedMulti:=0.7
	var sentryChargeSpeedMulti:=2
	
	if Upgrades.upgrade_count("Focus Fire")>0:
		sentryChargeSpeedMulti*=1+(0.5*min(enemiesKilled,5))
	if Upgrades.upgrade_count("AutoFire")>0:
		chargeSpeedMulti*=2
	
	chargeSpeedMulti*=pow(0.7,Upgrades.upgrade_count("Tighten Strings"))
	
	
	if arrowCharging:
		for i in range(20):
			$Line2D2.set_point_position(i, (float(i)/20)*Vector2(5000,0).rotated(self.get_angle_to(get_global_mouse_position())) *min(arrowCharge,1)+Vector2(0,400)*15*i*i*0.0025+Vector2(125,0).rotated(get_angle_to(get_global_mouse_position())))
		if arrowAiming:
			arrowCharge+=delta*chargeSpeedMulti*sentryChargeSpeedMulti
		
		else:
			arrowCharge+=delta*chargeSpeedMulti
		arrowCharge=min(arrowCharge,1)
	$Line2D.scale.x=lastDirection
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		moveVelocity.y = JUMP_VELOCITY

	

	
	
	
	knockbackVelocity= knockbackVelocity.move_toward(Vector2(0,0),3500*delta)
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		moveVelocity.x = direction * SPEED
		lastDirection=direction
	else:
		moveVelocity.x = move_toward(velocity.x, 0, SPEED)
	
	velocity=moveVelocity+knockbackVelocity
	
	if arrowAiming:
		velocity*=0
	move_and_slide()
	if not is_on_floor():
		if Input.is_action_pressed(&"ui_up") and velocity.y <=-200:
			moveVelocity += get_gravity() * delta * 2.05
		else:
			moveVelocity += get_gravity() * delta *5
	
	if is_on_floor():
		velocity.y=min(velocity.y,0)
	
	if Input.is_action_pressed(&"ui_up") and is_on_floor():
			moveVelocity.y = JUMP_VELOCITY

	if Input.is_action_pressed("Left Click") and attackCooldown<=0:
		attack(currWeapon)
		attackCooldown=weaponCooldownTimes[currWeapon]
	if Input.is_action_pressed("Right Click") and attackAbilityCooldown<=0:
		weaponAbility(currWeapon)
		attackAbilityCooldown=weaponAbilityCooldownTimes[currWeapon]
	if Input.is_action_just_pressed("ability"):
		useAbility(magicAbility)
	if (Input.is_action_just_released("Left Click")  or (Upgrades.upgrade_count("AutoFire")>0 and arrowCharge>=1)  ) and currWeapon=="Arrow":
		arrowCharging=false
		
		var newArrow=Tools.create(arrow,$"FirePoint/Arrow Sprite".global_position)
		newArrow.rotation=get_angle_to(get_global_mouse_position())
		newArrow.charge=arrowCharge
		
		
		if Upgrades.upgrade_count("Critical Attacks")>0:
			
			if arrowCharge>0.5 and arrowCharge<0.75:
				newArrow.critical=true
		arrowCharge=0

		if false:
			var newLaser = Tools.create(bowLaser,global_position)
			newLaser.scale.y=arrowCharge
			newLaser.rotation=get_angle_to(get_global_mouse_position())
	
	
	
	if Input.is_action_just_pressed("Right Click"):
		match currWeapon:
			"Arrow":
				arrowAiming=!arrowAiming
				sentryTime=0
				moveVelocity.y=0
				enemiesKilled=0
func attack(weapon):
	match weapon:
		"Star":
			var newStar:=star.instantiate()
			get_tree().current_scene.add_child(newStar)
			newStar.position=global_position
			newStar.get_child(0).rotation=get_angle_to(get_global_mouse_position())
			stars.append(newStar)
			stars.erase(null)
			if stars.size()>starCount:
				var returningStar=stars.pop_front()
				if returningStar!=null:
					returningStar.returning=true

		"Bat":
			var newSwing:=batSwing.instantiate()
			get_tree().current_scene.add_child(newSwing)
			newSwing.position=global_position
			newSwing.rotation=get_angle_to(get_global_mouse_position())
		"Arrow":
			
#			if !arrowCharging or Upgrades.playerUpgrades.has("AutoFire"):
#				var newArrow:=arrow.instantiate()
#				get_tree().current_scene.add_child(newArrow)
#				newArrow.position=$"FirePoint/Arrow Sprite".global_position+Vector2(300,0)
#				newArrow.rotation=get_angle_to(get_global_mouse_position())
			arrowCharging=true
		"Flamethrower":
			var newFlame:=flame.instantiate()
			get_tree().current_scene.add_child(newFlame)
			newFlame.position=global_position
		
		"Revolver":
			
			revolverAmmo=floor(revolverAmmo)
			reloadTimer=0.5
			
			if revolverAmmo>=1 and longReloading<=0:
				revolverAmmo-=1
				var newBullet:=bullet.instantiate()
				get_tree().current_scene.add_child(newBullet)
				newBullet.position=$FirePoint/Canvas.global_position
				
				newBullet.velocity=Vector2(4000,0).rotated(get_angle_to(get_global_mouse_position()))
				newBullet.get_child(0).rotation=get_angle_to(get_global_mouse_position())
		"Fish":
			var newFish:=fish.instantiate()
			get_tree().current_scene.add_child(newFish)
			newFish.position=global_position


func weaponAbility(weapon):
	match weapon:
		"Bat":
			var newBall:=ball.instantiate()
			get_tree().current_scene.add_child(newBall)
			newBall.position=global_position+Vector2(128,0)*lastDirection
			
		"Flamethrower":
			var newFuel:=fuel.instantiate()
			get_tree().current_scene.add_child(newFuel)
			newFuel.position=global_position
			if not is_on_floor():
				take_knockback(Vector2(-500,0).rotated(get_angle_to(get_global_mouse_position())))
		"Revolver":
			
			if longReloading<=0:
				longReloading=0
				for i in range(int(floor(revolverAmmo))):
					var newBullet:=bullet.instantiate()
					get_tree().current_scene.add_child(newBullet)
					newBullet.position=$FirePoint/Canvas.global_position
					
					newBullet.velocity=Vector2(6000,0).rotated(get_angle_to(get_global_mouse_position())+deg_to_rad(randf_range(-7,7)))
					newBullet.get_child(0).rotation=get_angle_to(get_global_mouse_position())
					reloadTimer=0.5
					revolverAmmo=floor(revolverAmmo-1)
					longReloading+=1
					await get_tree().create_timer(0.1).timeout
		"Fish":
			var newBait:=fishBait.instantiate()
			get_tree().current_scene.add_child(newBait)
			newBait.position=get_global_mouse_position()
		
			
			
func useAbility(ability):
	match ability:
		pass

func TakeDamage(Damage):
	if !invincible:
		invincibilityTime=1.0
		health -= Damage
		if health <= 0:
			get_tree().call_deferred(&"reload_current_scene")
		get_tree().current_scene.take_damage()


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy") and "contactDamage" in body:
		TakeDamage(body.contactDamage)
		
func take_knockback(vector):
	knockbackVelocity=vector
