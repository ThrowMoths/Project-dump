extends Area2D

var velocity:=Vector2(0,-2100)
var hit:=false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


func _process(delta: float) -> void:
	position+=velocity*delta
	velocity+=Vector2(0,800)*delta*7.5
	$Line2D.rotation+=delta*5


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Bat") and !hit and velocity.y>100:
		velocity=Vector2(6000,0).rotated(area.rotation)
		hit = true
		get_tree().current_scene.hit_stop(0.15,0)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") and hit:
		call_deferred("queue_free")
	if body.is_in_group("Enemy") and hit:
		body.take_damage(3)
		body.take_knockback(velocity *0.2)
		get_tree().current_scene.hit_stop(0.1,0)
		call_deferred("queue_free")
