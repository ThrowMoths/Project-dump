extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(0.3*scale.y*3).timeout
	call_deferred("queue_free")

func _process(delta: float) -> void:
	position+=Vector2(1500/scale.y,0).rotated(rotation) *delta


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(1.2)
