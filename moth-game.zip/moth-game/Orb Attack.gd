extends Area2D

var velocity:=Vector2(0,-1000)
@onready var projectile := preload("res://Small Enemy Attack.tscn")
var firing:=false

func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position+=velocity*delta
	velocity= velocity.move_toward(Vector2(0,0),1000*delta)
	if velocity.length()<=30 and !firing:
		firing=true
		fire()

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		velocity*=0

func fire():
	for i in range(32):
		var newProjectile:=projectile.instantiate()
		get_tree().current_scene.add_child(newProjectile)
		newProjectile.position=position
		scale=Vector2(scale.x-1.0/32,scale.y-1.0/32)
		newProjectile.angle=i*PI/8-PI/4
		newProjectile.spectral=true
		await get_tree().create_timer(0.1).timeout
	call_deferred("queue_free")

func burst():
	for i in range(6):
		var newProjectile:=projectile.instantiate()
		get_tree().current_scene.call_deferred("add_child",newProjectile)
		newProjectile.position=position
		newProjectile.angle=i*PI/3
	call_deferred("queue_free")
