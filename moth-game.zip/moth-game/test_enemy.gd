extends CharacterBody2D


var SPEED = 0*500.0
const JUMP_VELOCITY = -400.0
var maxHealth:=5.0
var Health := 5.0
var curse:=0.0
var Player = null
var TargetPos = Vector2.ZERO
var Direction = 1
var RaycastRange = 1000
var contamination:=0.0
var contaminationLevel:=0
var contaminationTime:=1.0
var cureTimer:=1.0
var shock:=0
var moveVelocity:=Vector2(0,0)
var knockbackVelocity:=Vector2(0,0)
@onready var curseWave:=preload("res://Curse Wave.tscn")

func contaminationDamage():
	take_damage(floor(contaminationLevel)*0.1)


func _physics_process(delta: float) -> void:
	contamination-=delta*(floor(contamination)+1)*0.5
	cureTimer-=delta*(1+contaminationLevel)*0.3
	if cureTimer<=0:
		cureTimer=1.0
		contaminationLevel=max(0,contaminationLevel-1)
	
	if contaminationLevel>0:
		$"Contamination Level".visible=true
		$"Contamination Level/RichTextLabel".text=str(contaminationLevel)
		contaminationTime-=delta*(contaminationLevel+1)
		if contaminationTime<=0:
			contaminationTime=1
			contaminationDamage()
	else:$"Contamination Level".visible=false
		

	$"Health Outline/Health Lerp".points[1].x=lerp($"Health Outline/Health Lerp".points[1].x, -100+Health/maxHealth*200,3*delta)
	modulate=lerp(modulate,Color(1,1,1),delta*2)
	if not is_on_floor():
		moveVelocity += get_gravity() * delta * 5
	Player = get_tree().current_scene.Player
	
	$Polygon2D.scale.x = Direction
	$AttackHitbox.position.x = Direction * 90
	$RayCast2D.target_position.x = Direction * RaycastRange
	
	#if $RayCast2D.get_collider().is_in_group("Player"):
	Direction = sign(Player.position.x - position.x)
	

	if abs(Player.position.x - position.x) < 200:
		attack()
	
	
	moveVelocity.x =(Direction * SPEED*(1-0.15*contaminationLevel))
	velocity=knockbackVelocity+moveVelocity
	knockbackVelocity= knockbackVelocity.move_toward(Vector2(0,0),3500*delta)
	
	
	move_and_slide()

func attack():
	$AttackHitbox/CollisionShape2D2.disabled = false
	await get_tree().create_timer(0.4).timeout
	$AttackHitbox/CollisionShape2D2.disabled = true

func take_damage(Damage):
	Health -= Damage
	if Health <= 0:
		get_tree().current_scene.enemyList.erase(self)
		
		Health=5.0
	modulate=Color(1,0,0)
	$"Health Outline/Health".set_point_position(1,Vector2(-100+$Player.health/$Player.maxHealth*200,-0))

func take_knockback(vector):
	knockbackVelocity=vector
	moveVelocity.y=0

func take_curse(curseDamage):
	curse+=curseDamage
	$"Health Outline/Curse".points[1].x=-100+curse/maxHealth*200
	if curse>Health:
		explode()

func explode():
	var newWave:=curseWave.instantiate()
	get_tree().current_scene.call_deferred("add_child",newWave)
	newWave.maxSize=curse/1.6
	newWave.position=position
	call_deferred("queue_free")

func add_contaminate(damage):
	contamination+=(damage)
	while contamination>1+0.5*contaminationLevel:
		contamination-=1+0.5*contaminationLevel
		contaminationLevel=min(4,contaminationLevel+1)
		cureTimer=1.0


func _on_attack_hitbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		if !body.invincible:
			body.TakeDamage(1)
