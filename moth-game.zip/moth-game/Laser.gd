extends Area2D

var collided:=false
var laserPos:=Vector2(0,0)
var lifeTime:=0.0

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	lifeTime+=delta
	if !collided and lifeTime<=2:
		scale.x+=delta*8000
		
	else:
		scale.y-=2*delta
	if scale.y<=0.1:
		call_deferred("queue_free")


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		await get_tree().process_frame

		collided=true
	if body.is_in_group("Enemy"):
		body.take_damage(3)
		
