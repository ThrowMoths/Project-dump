extends Node2D

var moveTimer:=1.0
var Player:Object=null
var Enemy:Object=null
@onready var smallSlime:=preload("res://small_slime.tscn")

func _process(delta: float) -> void:
	if Player==null:
		Player=get_tree().current_scene.Player
	if Enemy==null:
		Enemy=get_parent()
	
	moveTimer-=delta
	if moveTimer<=0:
		moveTimer=1.6
		Enemy.moveVelocity = Vector2(800*sign(Player.position.x-global_position.x),-1500)
	if Enemy.is_on_floor() and Enemy.moveVelocity.y>=0:
		Enemy.moveVelocity.x=0
	
func _on_test_enemy_death() -> void:
	for i in range(3):
		var newSlime:=smallSlime.instantiate()
		get_tree().current_scene.add_child(newSlime)
		newSlime.position=global_position 
		newSlime.moveVelocity=Vector2(randf_range(-500,500),-1000)
