extends Node2D

var maxLength:=300.0
var currLength:=0.0
var state:=0
var charge:=0.0
@onready var spark:=preload("res://Spark.tscn")

func _ready() -> void:
	await get_tree().process_frame
	modulate=Color(0.1+charge*0.8,0.1+charge*0.8,0.1)

func _process(delta: float) -> void:
	match state:
		0:
			currLength=min(maxLength,currLength+1500*delta)
			if currLength>=maxLength:
				state=1
		1:
			make_sparks(floor(charge*5))
			state=2
		2:
			currLength=max(0,currLength-2000*delta)
			if currLength>=maxLength:
				state=0
				call_deferred("queue_free")
	$Line2D.points[1].x=currLength
	$Area2D.scale.x=maxLength/100

func make_sparks(count):
	for i in count:
		var newSpark=spark.instantiate()
		get_tree().current_scene.add_child(newSpark)
		newSpark.position=global_position+$Line2D.points[1]*scale.x
		newSpark.rotation=deg_to_rad(randf_range(-30,30)+90*(scale.x-1))

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(1+charge*1.5)
