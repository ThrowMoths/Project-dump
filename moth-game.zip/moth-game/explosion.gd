extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(0.5).timeout
	call_deferred("queue_free")

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		call_deferred("queue_free")
	if body.is_in_group("Enemy"):
		body.take_damage(500/position.distance_squared_to(body.position))
		body.take_knockback(Vector2(800/position.distance_squared_to(body.position),0).rotated(-get_angle_to(body.position)))
		call_deferred("queue_free")
