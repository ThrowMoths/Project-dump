extends Area2D


var velocity:=Vector2(0,0)
var direction:=1.0
@onready var explosion:=preload("res://Explosion.tscn")
var scaleMult:=1.0
func _ready() -> void:
	velocity=Vector2(2000*direction,0).rotated(get_tree().current_scene.Player.get_angle_to(get_global_mouse_position())+deg_to_rad(randf_range(-5,5)))
	scaleMult=randf_range(1,1.8)
	await get_tree().create_timer(1).timeout
	

func _process(delta: float) -> void:
	position+=velocity*delta
	scale+=Vector2(delta,delta)*5*scaleMult
	$Line2D.modulate.a-=delta*2
	if $Line2D.modulate.a<=0:
		call_deferred("queue_free")
	
func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		call_deferred("queue_free")
	if body.is_in_group("Enemy"):
		body.take_knockback((velocity/(velocity.length()))*2000/scale.x)
		call_deferred("queue_free")
