extends Area2D


func _ready() -> void:
	await get_tree().create_timer(0.5).timeout
	call_deferred("queue_free")

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		area.get_parent().TakeDamage(2.0)
