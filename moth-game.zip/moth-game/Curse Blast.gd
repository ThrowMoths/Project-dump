extends Area2D

var maxSize:=1.0
func _ready() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	await get_tree().process_frame
	var newTween:=get_tree().create_tween()
	newTween.tween_property(self,"scale",Vector2(maxSize,maxSize),min(1,maxSize/4))
	var secondTween:=get_tree().create_tween()
	secondTween.tween_property(self,"modulate:a",0,min(1,maxSize/4))

func _process(_delta: float) -> void:
	if modulate.a<=0:
		call_deferred("queue_free")
func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_curse(maxSize*4)
