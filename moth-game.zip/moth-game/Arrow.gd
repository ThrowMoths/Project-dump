extends Area2D

var mode :="still"
var hit:=false
var velocity:=Vector2(0,0)
var damage:=0.0
var charge:=0.0
var critical:=false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	if critical:
		modulate=Color(1,1,0)
	velocity=Vector2(5000,0).rotated(get_tree().current_scene.Player.get_angle_to(get_global_mouse_position())) *min(charge,1)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
#	match mode:
#		"still":
#			global_position=player.firePoint.global_position
#			$Line2D.rotation=get_angle_to(get_global_mouse_position())
#		"moving":
	if !hit:
		position+=velocity*delta
		$Line2D.rotation=get_angle_to(global_position+velocity)
	velocity+=Vector2(0,800)*delta*15

	
	damage=charge*5
		

	if charge<=0.2:
		call_deferred("queue_free")


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") and !hit:
		velocity*=0
		hit=true
		await get_tree().create_timer(3.0).timeout
		
		call_deferred("queue_free")
		
	if body.is_in_group("Enemy")and !hit:
		var tempDamage=0+damage
		if Upgrades.upgrade_count("Ambush")>0 and body.Health==body.maxHealth and charge>=1.0:
			tempDamage*=1+(1.5*Upgrades.upgrade_count("Ambush"))
		if Upgrades.upgrade_count("Weak Point")>0 and body.Health==body.maxHealth:
			tempDamage*=1+Upgrades.upgrade_count("Weak Point")*(1-body.Health/body.maxHealth )
		if critical:
			tempDamage*=2
		tempDamage*= pow(1.75,Upgrades.upgrade_count("Tighten Strings"))
		
		body.take_damage(tempDamage)
		
		
		body.take_knockback(Vector2(2000,0).rotated(rotation))
		get_tree().current_scene.hit_stop(0.1,0)
