extends MeshInstance3D

var angle:=0.0

func _process(delta: float) -> void:
	position+=Vector3(0,0,2.5).rotated(Vector3(0,1,0),angle)*delta
	rotation.y=angle
