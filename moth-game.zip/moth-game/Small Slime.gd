extends Node2D

var moveTimer:=1.0
var Player:Object=null
var Enemy:Object=null


func _process(delta: float) -> void:
	if Player==null:
		Player=get_tree().current_scene.Player
	if Enemy==null:
		Enemy=get_parent()
	
	moveTimer-=delta
	if moveTimer<=0:
		moveTimer=1.6
		Enemy.moveVelocity =randf_range(0.8,1.2)* Vector2(500*sign(Player.position.x-global_position.x),-2000)
	if Enemy.is_on_floor() and Enemy.moveVelocity.y>=0:
		Enemy.moveVelocity.x=0
	
