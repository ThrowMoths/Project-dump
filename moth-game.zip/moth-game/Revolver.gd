extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if get_parent().longReloading>=0:
		modulate=Color(1,get_parent().revolverAmmo/6,get_parent().revolverAmmo/6)
	else:
		modulate=Color(1,1,1)
	rotation = move_toward(rotation,get_parent().revolverAmmo*PI/3,delta*10)
	$Line2D/Bullets/Node2D.visible=get_parent().revolverAmmo>=6.0
	$Line2D/Bullets/Node2D2.visible=get_parent().revolverAmmo>=5.0
	$Line2D/Bullets/Node2D3.visible=get_parent().revolverAmmo>=4.0
	$Line2D/Bullets/Node2D4.visible=get_parent().revolverAmmo>=3.0
	$Line2D/Bullets/Node2D5.visible=get_parent().revolverAmmo>=2.0
	$Line2D/Bullets/Node2D6.visible=get_parent().revolverAmmo>=1.0
