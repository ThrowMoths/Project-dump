extends Area2D

var direction:=Vector2(0,0)
var timePassed:=0.0
var insideWall:=false
var lastValidPos:=Vector2(0,0)
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	timePassed+=delta
	if timePassed<=2.0:
		position+=2400*direction*max((1-3*timePassed),0)*delta
	if timePassed<=2.5 and timePassed>=1.75:
		position.y+=1000*(timePassed-1.75)*delta
	if timePassed>=2.5:
		call_deferred(&"queue_free")


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		direction=direction*-1
		


func _on_player_simulation_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		insideWall=true
		lastValidPos=position

func _on_player_simulation_body_exited(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		insideWall=false
