extends Area2D

@onready var curseWave:=preload("res://Curse Wave.tscn")
var direction:=1
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	rotation+=delta*10*direction
	position.x+=1500*delta*direction


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy") :
		$Polygon2D2.color=Color(0.6,0.2,0.5)
		body.take_curse(2.0)
		body.add_to_group("PlayerCursed")
		await get_tree().create_timer(0.15).timeout
		var newCBlast:=curseWave.instantiate()
		get_tree().current_scene.add_child(newCBlast)
		newCBlast.position=position
		newCBlast.maxSize=2.5
		call_deferred("queue_free")
