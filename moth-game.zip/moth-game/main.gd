extends Node2D

@onready var Player := $Player

@onready var testEnemy :=preload("res://test_enemy.tscn")
@onready var slimeEnemy :=preload("res://slime enemy.tscn")
@onready var orbEnemy :=preload("res://Orb Enemy.tscn")
@onready var crushingEnemy :=preload("res://Crushing Enemy.tscn")
@onready var sporeEnemy :=preload("res://Spore Enemy.tscn")
@onready var jugglerEnemy :=preload("res://Juggler Enemy.tscn")

var enemyList:=[]
var options:=["","",""]
var enemyTypes:=[]
var currEnemyIndex:=0
var experience:=0
var expCost:=100
func _ready() -> void:
	await get_tree().process_frame
	enemyTypes=[slimeEnemy,orbEnemy,crushingEnemy,sporeEnemy,jugglerEnemy]
	
	for i in get_children(true):
		if i.is_in_group("Enemy"):
			enemyList.append(i)


func _process(delta: float) -> void:
	$Camera2D/RichTextLabel.text="[b]"+str(Player.currWeapon)
	$"Camera2D/Line2D/Health Lerp".set_point_position(1,Vector2(lerp($"Camera2D/Line2D/Health Lerp".get_point_position(1).x,$"Camera2D/Line2D/Health".get_point_position(1).x,5*delta),-160) )
	
	
	
	
	if Input.is_action_just_pressed(&"ui_cut"):
		get_tree().call_deferred(&"reload_current_scene")
	if Input.is_action_just_pressed("ui_copy"):
		Tools.create(enemyTypes[currEnemyIndex],get_global_mouse_position())
	if Input.is_action_just_pressed("ui_paste"):
		currEnemyIndex=(currEnemyIndex+1)%enemyTypes.size()
	
	if Input.is_action_just_pressed("Open Upgrades"):
		open_upgrades()
	if Input.is_action_just_pressed("Close Upgrades"):
		$"Camera2D/Upgrade Menu".visible=false
	
	if Input.is_action_just_pressed("ui_cancel") and !$"Camera2D/Upgrade Menu".visible:
		$"Camera2D/View Upgrades".visible=!$"Camera2D/View Upgrades".visible
	
	$Camera2D.position=$Camera2D.position+(($Player.position-$Camera2D.position)+(get_global_mouse_position()-$Camera2D.position)*0.2) *delta

func take_damage():

	$Camera2D/Line2D/Health.set_point_position(1,Vector2(-100+$Player.health/$Player.maxHealth*200,-160))
	hit_stop(0.15,0.05)
func hit_stop(duration,strength):
	Engine.time_scale=strength
	await get_tree().create_timer(duration,true,false,true).timeout
	Engine.time_scale=1
 
func option_chosen(index):
	Upgrades.add_upgrade(options[index])
	$"Camera2D/Upgrade Menu".visible=false
	$"Camera2D/View Upgrades".update_upgrade_list()
	get_tree().paused=false

func open_upgrades():
	get_tree().paused=true
	$"Camera2D/Upgrade Menu".visible=true
	roll_upgrades()
func add_experience_orb(value):
	experience+=value


func _on_button_button_down() -> void:
	if experience>expCost:
		experience-=expCost
		roll_upgrades()
		expCost*=1.2
		$"Camera2D/Upgrade Menu/Button/RichTextLabel".text="[center][b]Reroll[br]-"+str(roundi(expCost))
	else:
		$Camera2D/RichTextLabel2.modulate=Color(1,0,0)
func roll_upgrades():
	var choices = Upgrades.generate_choices(3)
	var count:=0
	for choice in choices:
		$"Camera2D/Upgrade Menu".get_child(count).get_child(0).text="[center][b]"+choice["Name"]
		if Upgrades.upgrade_count(choice["Name"])>0:
			$"Camera2D/Upgrade Menu".get_child(count).get_child(0).text=$"Camera2D/Upgrade Menu".get_child(count).get_child(0).text+" (x "+str(1+Upgrades.upgrade_count(choice["Name"]))+")"
		$"Camera2D/Upgrade Menu".get_child(count).get_child(1).text="[b]"+choice["Description"]
		$"Camera2D/Upgrade Menu".get_child(count).get_child(2).text="[b]Tags:"+",".join(choice["Tags"])
		options[count]=choice["Name"]
		count+=1
