extends Area2D

var target:Object=null
var speed:=400.0
var angle:=0.0

var turnSpeed:=1.0

var potentialTargets:=[]
var hitCounter:=0

func _ready() -> void:
	
	
	
	turnSpeed=randf_range(0.75,1.25)
	speed*=randf_range(0.8,1.2)
	
	var fishLayer:=randi_range(1,10)
	z_index =fishLayer
	modulate=(0.5+(float(fishLayer))/20)*Color(1,1,1)
	modulate.a=1
	for i in get_tree().get_nodes_in_group("Bait"):
		new_target(i)
	
	await get_tree().create_timer(15).timeout
	call_deferred("queue_free")
func _process(delta: float) -> void:
	if angle>PI:
		angle-=PI*2
	if angle<-PI:
		angle+=PI*2
	
	var targetAngle=0
	if target!=null:
		targetAngle=self.get_angle_to(target.global_position)-angle
	
	else:
		targetAngle=self.get_angle_to(get_global_mouse_position())-angle
	
	if targetAngle>PI:
		targetAngle-=PI*2
	if targetAngle<-PI:
		targetAngle+=PI*2
	
	position+=Vector2(speed,0).rotated(angle)*delta
	
	angle=move_toward(angle,angle+targetAngle,2*PI*delta)
	
	
	$Node2D.rotation=angle

func new_target(newObject):
	potentialTargets.append(newObject)
	potentialTargets.sort_custom(func(a,b): return position.distance_to(a.position)<position.distance_to(b.position))
	
	target=potentialTargets[0]
	


func target_removed(newObject):
	potentialTargets.erase(newObject)
	potentialTargets.erase(null)
	potentialTargets.sort_custom(func(a,b): return position.distance_to(a.position)<position.distance_to(b.position))
	
	if potentialTargets.size()>=1:
		target=potentialTargets[0]


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(0.1)
		hitCounter+=1
		if hitCounter>=10:
			call_deferred("queue_free")

func free():
	call_deferred("queue_free")
