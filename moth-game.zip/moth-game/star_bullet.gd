extends Area2D

var speed:=2000.0
var returnSpeed:=3000.0
var velocity:=Vector2(0,0)
var returning:=false
var damage:=2
var movementAngle:=0.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	movementAngle=$Sprite2D.rotation
	await get_tree().create_timer(0.3).timeout
	var newTween:=get_tree().create_tween()
	newTween.tween_property(self,"speed",0,0.5)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if !returning:
		velocity=Vector2(speed,0).rotated(movementAngle)
		$Sprite2D.rotation+=delta*30
	else:
		$Sprite2D.look_at(get_tree().current_scene.Player.position)
		velocity=Vector2(returnSpeed,0).rotated($Sprite2D.rotation)
	position+=velocity*delta
	if position.distance_to(get_tree().current_scene.Player.position)<50 and returning:
		call_deferred("queue_free")
		

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") or body.is_in_group("Enemy"):

		var newTween:=get_tree().create_tween()
		newTween.tween_property(self,"speed",0,0.5)
		if body.is_in_group("Enemy"):
			body.take_damage(damage)
		elif body.is_in_group("Solid Wall"):
			await get_tree().create_timer(0.5).timeout
			returning=true
func _input(event: InputEvent) -> void:
	if Input.is_action_just_pressed("Right Click"):
		returning=true
func free():
	call_deferred("queue_free")
