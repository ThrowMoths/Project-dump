extends Node2D

var attackTimer:=2.0
var Player:Object=null
var Enemy:Object=null
@onready var spore:=preload("res://Spore.tscn")
func _process(delta: float) -> void:
	if Player==null:
		Player=get_tree().current_scene.Player
	if Enemy==null:
		Enemy=get_parent()

	attackTimer-=delta
	if attackTimer<=0 :
		attackTimer=2.0
		for i in range(-2,3):
			var newSpore:=spore.instantiate()
			get_tree().current_scene.add_child(newSpore)
			newSpore.position=global_position-Vector2(0,100)
			newSpore.angle=-PI/2 +i*PI/12+randf_range(-PI/12,PI/12)
