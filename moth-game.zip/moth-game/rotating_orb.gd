extends Area2D

var centre:Object=null
var index:=0
@onready var projectile:=preload("res://Small Enemy Attack.tscn")

func _process(_delta: float) -> void:
	if centre!=null:
		position=centre.position+Vector2(0,64)+Vector2(250,0).rotated(Time.get_ticks_msec()/300.0+PI/6*index)
	else :
		fire()


func fire():
	var newAttack = Tools.create(projectile,global_position)
	newAttack.angle=self.get_angle_to(get_tree().current_scene.Player.position)
	newAttack.spectral=true
	call_deferred("queue_free")
