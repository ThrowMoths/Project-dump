extends StaticBody2D


func _ready() -> void:
	var newTween:=get_tree().create_tween()
	newTween.tween_property(self,"modulate:a",0,2)
	await get_tree().create_timer(2).timeout
	call_deferred("queue_free")
func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.is_in_group("Player"):
		call_deferred("queue_free")
