extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	modulate=Color(1,1,1)
	if Upgrades.upgrade_count("Critical Attacks")>0 and get_parent().arrowCharge>0.5 and get_parent().arrowCharge<0.75:
		modulate=Color(1,1,0)
	elif get_parent().arrowCharge>=1:
		modulate=Color(1,0,0)
	match get_parent().currWeapon:
		"Arrow":
			$Line2D.visible=get_parent().arrowCharge>0
			$Line2D2.visible=get_parent().arrowCharge>0.25
			$Line2D3.visible=get_parent().arrowCharge>0.5
			$Line2D4.visible=get_parent().arrowCharge>=0.75
		_:
			visible=false
