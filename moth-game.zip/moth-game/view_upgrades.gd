extends Node2D

func update_upgrade_list():
	$RichTextLabel.text="[b]"
	for key in Upgrades.playerUpgrades.keys():
		if Upgrades.playerUpgrades[key]>1:
			$RichTextLabel.text=$RichTextLabel.text+key+"(X"+str(Upgrades.playerUpgrades[key])+")[br]"
		else:
			$RichTextLabel.text=$RichTextLabel.text+key+"[br]"
