extends Area2D


@onready var spark:=preload("res://Spark.tscn")
func _ready() -> void:
	await get_tree().create_timer(4).timeout
	call_deferred("queue_free")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x+=scale.x*1200*delta


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(3)
		var newSpark=spark.instantiate()
		get_tree().current_scene.add_child(newSpark)
		newSpark.position=global_position
		newSpark.rotation=deg_to_rad(-195+90*(scale.x-1))
		var secondSpark=spark.instantiate()
		get_tree().current_scene.add_child(secondSpark)
		secondSpark.position=global_position
		secondSpark.rotation=deg_to_rad(-165+90*(scale.x-1))
