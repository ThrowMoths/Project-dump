extends Area2D

var spectral:=false
var angle:=0.0
var speed:=800.0
var velocity:=Vector2(0,0)
@onready var parriedBullet:=preload("res://Parried Bullet.tscn")

func _ready() -> void:
	await get_tree().process_frame
	if spectral:
		modulate.a=0.7
	velocity=Vector2(speed,0).rotated(angle)
	await get_tree().create_timer(5.0).timeout
	call_deferred("queue_free")
func _process(delta: float) -> void:
	if velocity.length()>50:
		$Polygon2D.rotation=self.get_angle_to(position+velocity)
	position+=velocity*delta
	


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") and !spectral:
		call_deferred("queue_free")



func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		area.get_parent().TakeDamage(1.0)
		area.get_parent().take_knockback(velocity)
	if area.is_in_group("Bat"):
		var newAttack:=parriedBullet.instantiate()
		get_tree().current_scene.add_child(newAttack)
		newAttack.position=position
		newAttack.angle=(area.rotation)
		newAttack.spectral=spectral
		get_tree().current_scene.hit_stop(0.25,0)
		call_deferred("queue_free")
	if area.is_in_group("Extinguisher"):
		velocity+=area.velocity*0.1
