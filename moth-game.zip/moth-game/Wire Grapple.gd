extends Node2D

var direction:=1
var rerurning=false

func _ready() -> void:
	pass


func _process(delta: float) -> void:
	$Area2D.position.x+=1500*delta

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy") or body.is_in_group("Solid Wall"):
		get_tree().current_scene.Player.hook_latched()
