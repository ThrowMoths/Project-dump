extends Area2D

var mode:="following"
var countDown:=3.0
func _ready() -> void:
	var newTween:=get_tree().create_tween()
	newTween.tween_property($Polygon2D,"color",Color(255.0/255,41.0/255,87.0/255),countDown)

func _process(delta: float) -> void:
	
	if  mode=="following":
		position=get_tree().current_scene.Player.position + Vector2(0,-800)
	elif mode=="falling" :
		position.y+=abs(countDown)*980*7*delta
	if mode!="waiting":
		countDown-=delta
	if countDown<=0:
		
		mode="waiting"
		await get_tree().create_timer(0.5).timeout
		mode="falling"
	

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") and countDown<-0.3 and mode=="falling":
		call_deferred("queue_free")
	if body.is_in_group("Enemy") and mode=="falling":
		body.take_damage(3)


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		area.get_parent().TakeDamage(4.0)
