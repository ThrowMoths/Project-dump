extends Area2D


func _ready() -> void:
	get_tree().call_group("Fish","new_target",self)
	await get_tree().create_timer(3.0).timeout
	get_tree().call_group("Fish","target_removed",self)
	call_deferred("queue_free")

func free():
	call_deferred("queue_free")
