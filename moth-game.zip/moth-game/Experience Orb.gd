extends Area2D

var velocity:=Vector2(0,0)
var value:=50.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position+=velocity*delta
	velocity= velocity.move_toward(Vector2(3000,0).rotated(get_angle_to(get_tree().current_scene.Player.position)),5000*delta)






func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		get_tree().current_scene.add_experience_orb(value)
		call_deferred("queue_free")
