extends Area2D

var timePassed:=0.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	timePassed+=delta
	position.y+=sin(timePassed)




func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		get_tree().current_scene.open_upgrades()
		call_deferred("queue_free")
