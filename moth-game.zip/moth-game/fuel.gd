extends Area2D


var velocity:=Vector2(0,0)
var timer:=3.0
@onready var explosion:=preload("res://Explosion.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	velocity=Vector2(2000,0).rotated(get_tree().current_scene.Player.get_angle_to(get_global_mouse_position()))
	await get_tree().create_timer(8).timeout
	call_deferred_thread_group("queue_free")

func _process(delta: float) -> void:
	position+=velocity*delta
	$RichTextLabel.text=str(ceil(timer))
	if velocity.length()>=0.1:
		velocity+=Vector2(0,800)*delta*15
	timer-=delta
	if timer<=0:
		var newExplosion:=explosion.instantiate()
		get_tree().current_scene.add_child(newExplosion)
		newExplosion.position=position
		call_deferred("queue_free")

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		velocity.y=-abs(velocity.y)



func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Igniting"):
		var newExplosion:=explosion.instantiate()
		get_tree().current_scene.add_child(newExplosion)
		newExplosion.position=position
		call_deferred("queue_free")
