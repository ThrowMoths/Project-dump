extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass




func _on_button_1_button_up() -> void:
	get_tree().current_scene.option_chosen(0)


func _on_button_2_button_up() -> void:
	get_tree().current_scene.option_chosen(1)


func _on_button_3_button_up() -> void:
	get_tree().current_scene.option_chosen(2)


func _on_button_1_mouse_entered() -> void:
	pass#$"Choice 1".modulate = $"Choice 1".modulate.lightened(2)
	
func _on_button_1_mouse_exited() -> void:
	pass#$"Choice 1".modulate = $"Choice 1".modulate.darkened(0.5)



func _on_button_2_mouse_entered() -> void:
	pass # Replace with function body.
func _on_button_2_mouse_exited() -> void:
	pass # Replace with function body.


func _on_button_3_mouse_entered() -> void:
	pass # Replace with function body.
func _on_button_3_mouse_exited() -> void:
	pass # Replace with function body.
