extends Area2D

var tickTimer:=1.0
var enteredEnemies:=[]
func _ready() -> void:
	await get_tree().create_timer(5.0).timeout
	call_deferred("queue_free")


func _process(delta: float) -> void:
	tickTimer-=delta*5
	if tickTimer<=0:
		tick_damage(0.3)
		tickTimer=1.0
func tick_damage(damage):
	for i in enteredEnemies:
		i.take_curse(damage)

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		enteredEnemies.append(body)


func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		enteredEnemies.erase(body)
