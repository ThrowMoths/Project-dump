extends Node2D
var start=null
var end=null
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	
	if end==null or start==null:
		call_deferred("queue_free")
	else:
		$Line2D.points[0]=start.position-position
		$Line2D.points[1]=end.position-position


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	modulate.a-=delta*3
	if modulate.a<=0:
		call_deferred("queue_free")
