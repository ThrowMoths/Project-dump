extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("Left Click"):
		$Polygon2D2.visible=true
		$Polygon2D3.visible=true
		$Label.visible=true
		$Line2D.visible=true
		
		$Polygon2D6.visible=false
		$Line2D2.visible=false
		await get_tree().create_timer(0.5).timeout
		$Polygon2D2.visible=false
		$Polygon2D3.visible=false
		$Label.visible=false
		$Line2D.visible=false
		$Polygon2D6.visible=true
		$Line2D2.visible=true
