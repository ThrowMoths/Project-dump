extends Area2D


var angle:=0.0
var speed:=6000.0
var spectral:=false
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Polygon2D.rotation=angle
	position+=Vector2(speed,0).rotated(angle)*delta
	


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") and !spectral:
		call_deferred("queue_free")
	if body.is_in_group("Enemy"):
		body.take_damage(1.0)
		call_deferred("queue_free")
