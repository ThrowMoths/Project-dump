extends Area2D

var velocity:=Vector2(0,0)
# Called when the node enters the scene tree for the first time.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position+=velocity*delta

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		call_deferred("queue_free")
	if body.is_in_group("Enemy"):
		body.take_damage(2.5)
		body.take_knockback(velocity/5)
		get_tree().current_scene.hit_stop(0.1,0)
		call_deferred("queue_free")
