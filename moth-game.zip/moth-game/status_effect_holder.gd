class_name Status extends Node2D

var effects:={"Fire":preload("res://Fire Status Effect.webp")}
var currEffect:="None"
