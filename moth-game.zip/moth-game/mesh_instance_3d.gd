extends MeshInstance3D


@onready var projectile:=preload("res://3d Projectile.tscn")
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_pressed("ui_left"):
		rotation.y-=PI*delta
	elif Input.is_action_pressed("ui_right"):
		rotation.y+=PI*delta
	if Input.is_action_just_pressed("Left Click"):
		var newProjectile:=projectile.instantiate()
		get_tree().current_scene.add_child(newProjectile)
		newProjectile.position=position
		newProjectile.angle=rotation.y
		
