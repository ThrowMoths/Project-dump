extends Area2D

var yVelocity:=-500.0
@onready var toxicPool:=preload("res://Toxic Pool.tscn")


func _process(delta: float) -> void:
	$Line2D.rotation+=delta*5*scale.x
	
	position.x+=500*scale.x*delta
	
	position.y+=yVelocity*delta
	
	yVelocity+=1200*delta




func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		var newPool:=toxicPool.instantiate()
		get_tree().current_scene.add_child(newPool)
		newPool.position=position+Vector2(0,48)
		call_deferred("queue_free")
		
