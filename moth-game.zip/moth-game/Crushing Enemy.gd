extends Node2D

var attackTimer:=3.0
var Player:Object=null
var Enemy:Object=null
var currAnvil:Object=null
@onready var anvil:=preload("res://Anvil Attack.tscn")
func _process(delta: float) -> void:
	if Player==null:
		Player=get_tree().current_scene.Player
	if Enemy==null:
		Enemy=get_parent()

	if currAnvil==null:
		attackTimer-=delta
	if attackTimer<=0 :
		attackTimer=2.0
		var newAnvil:=anvil.instantiate()
		get_tree().current_scene.add_child(newAnvil)
		newAnvil.position=Vector2(-999999,-999999)
		currAnvil=newAnvil
	
