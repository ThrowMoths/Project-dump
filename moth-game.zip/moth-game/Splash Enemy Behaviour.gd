extends Node2D

var attackTimer:=3.0
var Player:Object=null
var Enemy:Object=null
var currOrb:Object=null
@onready var orb:=preload("res://Orb Attack.tscn")
func _process(delta: float) -> void:
	if Player==null:
		Player=get_tree().current_scene.Player
	if Enemy==null:
		Enemy=get_parent()

	if self.global_position.distance_to(Player.position)<500 and currOrb==null:
		Enemy.moveVelocity.x =-600*sign(Player.position.x-global_position.x)
	
	elif self.global_position.distance_to(Player.position)>1200 and currOrb==null:
		Enemy.moveVelocity.x =600*sign(Player.position.x-global_position.x)
	else:
		Enemy.moveVelocity.x =0
	if currOrb==null:
		attackTimer-=delta
	if attackTimer<=0 :
		attackTimer=2.0
		var newOrb:=orb.instantiate()
		get_tree().current_scene.add_child(newOrb)
		newOrb.position=global_position
		currOrb=newOrb
	


func _on_test_enemy_hit() -> void:
	if currOrb!=null:
		currOrb.burst()
