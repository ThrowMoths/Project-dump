extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var newTween:=get_tree().create_tween()
	newTween.tween_property($Area2D,"scale:y",4,0.2)
	await get_tree().create_timer(1).timeout
	call_deferred("queue_free")


func _process(delta: float) -> void:
	$Polygon2D.position.y=-96*$Area2D.scale.y
func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(4)
