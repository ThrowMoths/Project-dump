extends Node2D

var falling:=0

func _ready() -> void:
	pass


func _process(delta: float) -> void:
	if falling==0:
		$Pillar.scale.y+=delta*5
		if $Pillar.scale.y>=8:
			falling=1
	elif falling==2:
		$Pillar.scale.y-=delta*10
	if $Pillar.scale.y<=0 and falling==2:
		call_deferred("queue_free")
	$Area2D.position.y=$Pillar.scale.y*-96

func _input(_event: InputEvent) -> void:
	if Input.is_action_just_released("mobility") :
		falling=1


func _on_area_2d_body_exited(body: Node2D) -> void:
	if body.is_in_group("Player"):
		falling=2
