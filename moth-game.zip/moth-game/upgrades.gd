extends Node

var totalUpgradeList:={}
var playerUpgrades :={}
var upgradePool:=[]
var currUpgradePool:=[]
var tags:={}
 
func _ready() -> void:
	var upgradeText:=FileAccess.open("res://Total Upgrade List.txt",FileAccess.READ).get_as_text()
	var splitUpgradeText= upgradeText.split("\n\n")
	for i in range(splitUpgradeText.size()):
		var currUpgrade =splitUpgradeText[i].split("\n")
		upgradePool.append(currUpgrade[0])
		totalUpgradeList[currUpgrade[0]]={"Name":currUpgrade[0],"Type":currUpgrade[1],"Description":currUpgrade[2],"Requirements":(currUpgrade[3] .split(",")),"Restrictions":(currUpgrade[4] .split(",")),"Max Count":int(currUpgrade[5]),"Tags":currUpgrade[6].split(",")}
		totalUpgradeList[currUpgrade[0]]["Requirements"].erase("None")
		totalUpgradeList[currUpgrade[0]]["Restrictions"].erase("None")
	update_pool()

func generate_choices(count):
	var tempPool:=currUpgradePool.duplicate(true)
	var choices:=[]
	for i in range(min(currUpgradePool.size(),count)):
		tempPool.shuffle()
		choices.append(totalUpgradeList[tempPool.pop_front()])
	return choices

func add_upgrade(upgrade):
	if playerUpgrades.has(upgrade):
		playerUpgrades[upgrade]+=1
	else:
		playerUpgrades[upgrade]=1
	for i in totalUpgradeList[upgrade]["Tags"]:
		if tags.has(i):
			tags[i]+=1
		else:
			tags[i]=1
	update_pool()

func update_pool():
	var tempPool:=[]
	for upgrade in upgradePool:
		var valid:=true
		if playerUpgrades.has(upgrade):
			if playerUpgrades[upgrade]>=totalUpgradeList[upgrade]["Max Count"]:
				valid=false
		for requirement in totalUpgradeList[upgrade]["Requirements"]:
			if tags.has(requirement):
				if tags[requirement]<=0:
					valid=false
			if !playerUpgrades.has(requirement):
				valid=false
		for restriction in totalUpgradeList[upgrade]["Restrictions"]:
			if tags.has(restriction):
				if tags[restriction]>0:
					valid=false
			if playerUpgrades.has(restriction):
				valid=false
		
		if valid:
			tempPool.append(upgrade)
	currUpgradePool=tempPool.duplicate(true)

func upgrade_count(upgrade):
	if playerUpgrades.has(upgrade):
		return playerUpgrades[upgrade]
	return 0
