extends Node


func create(object,position:=Vector2(-999999,-999999)):
	var newObject=object.instantiate()
	get_tree().current_scene.add_child(newObject)
	newObject.position=position
	return newObject
