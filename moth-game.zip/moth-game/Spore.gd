extends Area2D


var angle:=0.0
var speed:=500.0
var velocity:=Vector2(0,0)
@onready var explosion:=preload("res://enemy explosion.tscn")
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _ready() -> void:
	await get_tree().process_frame
	velocity=Vector2(speed*randf_range(0.75,1.25),0).rotated(angle)
	await get_tree().create_timer(randf_range(1.2,1.8)).timeout
	explode()
func _process(delta: float) -> void:
	position+=velocity*delta
	velocity+=Vector2(0,980)*delta*0.5


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Solid Wall"):
		explode()



func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Player"):
		explode()
	if area.is_in_group("Bat"):
		explode()
	if area.is_in_group("Extinguisher"):
		velocity+=area.velocity*0.1
func explode():
	var newExplosion:=explosion.instantiate()
	get_tree().current_scene.add_child(newExplosion)
	newExplosion.position=position
	call_deferred("queue_free")
