extends Area2D

var type:="None"
var enteredEnemies:=[]
var enteredProjectiles:=[]
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	visible=get_parent().arrowAiming
	if visible:
		if Upgrades.playerUpgrades.has("Slowing Aura"):
			modulate=Color(0.3,1,1)
			modulate.a=1-pow(0.7,Upgrades.playerUpgrades["Slowing Aura"])
			for projectile in enteredProjectiles:
				projectile.velocity= projectile.velocity.move_toward(Vector2(0,400).rotated(self.get_angle_to(projectile.position)),delta*600*Upgrades.playerUpgrades["Slowing Aura"])

		elif Upgrades.playerUpgrades.has("Damaging Aura"):
			modulate=Color(1,0.3,0.3)
			modulate.a=1-pow(0.7,Upgrades.playerUpgrades["Damaging Aura"])
			for enemy in enteredEnemies:
				enemy.take_damage(delta*2*Upgrades.playerUpgrades["Damaging Aura"])


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		enteredEnemies.append(body)



func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		if body in enteredEnemies:
			enteredEnemies.erase(body)



func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Projectile"):
		enteredProjectiles.append(area)


func _on_area_exited(area: Area2D) -> void:
	if area.is_in_group("Projectile"):
		if area in enteredProjectiles:
			enteredProjectiles.erase(area)
