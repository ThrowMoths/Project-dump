extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	fade()
	await get_tree().create_timer(0.3).timeout
	call_deferred("queue_free")

func fade():
	var newTween=get_tree().create_tween()
	newTween.tween_property(self,"modulate:a",1,0.2)
	await get_tree().create_timer(0.2).timeout
	var secondTween=get_tree().create_tween()
	secondTween.tween_property(self,"modulate:a",0,0.1)
func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(2)
		body.take_knockback(Vector2(2000,0).rotated(rotation))
		get_tree().current_scene.hit_stop(0.2,0)
