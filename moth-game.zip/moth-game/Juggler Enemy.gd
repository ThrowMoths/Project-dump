extends Node2D

var attackTimer:=0.2
var reloadTimer:=1.0
var maxAmmo:=12

var ammoList:=[]
var mode:="reloading"
var Player:Object=null
var Enemy:Object=null

var minFire:=true

@onready var orb:=preload("res://Rotating Orb.tscn")
func _process(delta: float) -> void:
	mode="loading"
	if ammoList.size()>=4:
		minFire=true
	
	if $RayCast2D.get_collider()!=null:
		if $RayCast2D.get_collider().is_in_group("Player"):
			$Line2D.points[1]=Player.position-global_position
			$Line2D.visible=true and false
			if !ammoList.is_empty() and minFire:
				mode="firing"
			else:
				minFire=false
		else:
			$Line2D.visible=false
#			mode="loading"
	if Player==null:
		Player=get_tree().current_scene.Player
	if Enemy==null:
		Enemy=get_parent()
	$RayCast2D.target_position=Player.position-global_position
	if self.global_position.distance_to(Player.position)<500 :
		Enemy.moveVelocity.x =-600*sign(Player.position.x-global_position.x)
	
	elif self.global_position.distance_to(Player.position)>1200:
		Enemy.moveVelocity.x =600*sign(Player.position.x-global_position.x)


	if mode=="firing":
		Enemy.moveVelocity.x =0
		attackTimer-=delta
		
	
		
		if attackTimer<=0:
			reloadTimer=1.0
			attackTimer=0.2
			attack()
	else:
		reloadTimer-=delta
		if reloadTimer<=0 and ammoList.size()<maxAmmo:
			reloadTimer=1.0
			attackTimer=0.2
			reload()

func attack():
	var currObject= ammoList.pop_back()
	currObject.fire()

func reload():
	var newOrb=Tools.create(orb)
	ammoList.push_back(newOrb)
	newOrb.centre=Enemy
	newOrb.index=ammoList.size()
