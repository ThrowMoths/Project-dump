extends Node2D



var attackCooldown:=2

var Player:Object=null
var Enemy:Object=null

func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$RayCast2D.target_position=Player.position-global_position
	if $RayCast2D.get_collider()!=null:
		if $RayCast2D.get_collider().is_in_group("Player"):
			$Line2D.visible=true

		else:
			$Line2D.visible=false
#			mode="loading"
