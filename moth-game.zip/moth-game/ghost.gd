extends Node2D

var velocity:=Vector2(0,0)
var timePassed:=0
var speed:=1200
var angle:=0.0
@onready var target=null
@onready var curseBlast:=preload("res://Curse Wave.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	velocity=Vector2(speed,0).rotated(angle)
	$Line2D.rotation=angle
	position+=velocity*delta
	if target!=null:
		angle=lerp_angle(angle,get_angle_to(target.position),0.15)
		if position.distance_to(target.position)<100:
			target.take_curse(1.0)
			call_deferred("queue_free")


func explode():
	var newWave:=curseBlast.instantiate()
	get_tree().current_scene.call_deferred("add_child",newWave)
	newWave.maxSize=0.9
	newWave.position=position
	call_deferred("queue_free")
