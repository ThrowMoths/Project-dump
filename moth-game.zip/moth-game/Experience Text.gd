extends RichTextLabel

var expValue:=0.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


func _process(delta: float) -> void:
	expValue=move_toward(expValue,get_tree().current_scene.experience,100*delta)
	expValue=lerp(expValue,float(get_tree().current_scene.experience),delta)
	text="[b]"+str(roundi(expValue))
	modulate.b=move_toward(modulate.b,1,delta)
	modulate.g=move_toward(modulate.g,1,delta)
