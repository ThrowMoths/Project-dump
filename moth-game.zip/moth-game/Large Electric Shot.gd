extends Area2D


@onready var zap:=preload("res://Zap.tscn")

func _ready() -> void:
	create_sparks()
	await get_tree().create_timer(5).timeout
	call_deferred("queue_free")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x+=scale.x*500*delta


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(3)
		

func create_sparks():
	await get_tree().create_timer(0.4).timeout
	var sortList=shortest_dist_enemy()
	for i in range(min(3,sortList.size())):
		var newSpark=zap.instantiate()
		get_tree().current_scene.add_child(newSpark)
		newSpark.position=global_position
		newSpark.start=self
		
		if sortList.size()>i:
			if sortList[i]!=null:
				if position.distance_to(sortList[i].position)<500:
					newSpark.end=sortList[i]
					sortList[i].take_damage(1.5)
	create_sparks()

func shortest_dist_enemy():
	var list:Array= get_tree().current_scene.enemyList
	list.sort_custom(func(a,b): return position.distance_to(a.position)<position.distance_to(b.position))
	return list
