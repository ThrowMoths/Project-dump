extends Area2D


func _ready() -> void:
	await get_tree().create_timer(4).timeout
	call_deferred("queue_free")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x+=scale.x*1200*delta


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.add_contaminate(3)

	elif body.is_in_group("Solid Wall"):
		call_deferred("queue_free")
