extends Node2D

var maxScale:=0.4
var lifeTime:=2.0
var disappearing:=false
@onready var crystal_spike:=preload("res://Crystal Spike.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	var newTween:= get_tree().create_tween()
	newTween.tween_property($Area2D,"scale:y",maxScale,0.3*min(maxScale,1))
	await get_tree().create_timer(0.15*min(maxScale,1)).timeout
	create_new_spike()
	await get_tree().create_timer(lifeTime-0.15*min(maxScale,1)).timeout
	var secondTween:=get_tree().create_tween()
	secondTween.tween_property($Area2D,"scale:y",0,0.15*min(maxScale,1))

func create_new_spike():
	if $RayCast2D.is_colliding() and maxScale<3:
		var newSpike:=crystal_spike.instantiate()
		get_tree().current_scene.add_child(newSpike)
		newSpike.maxScale=maxScale+0.8
		newSpike.position=$RayCast2D.global_position
		newSpike.scale.x=scale.x


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(0.5)
