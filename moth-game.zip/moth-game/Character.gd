extends CharacterBody2D


const SPEED = 900.0

const JUMP_VELOCITY = -1000.0
var Health := 10.0
var curse:=0.0
var maxHealth:=10.0
var characterIndex:=0
var characters:=["Magician","Sword","Crystal","Curse","Mecha","Disease"]
var charge:=0.0
var charging:=false
var LookingUp = false
var LookingDown = false
var CanAttack = true
var AttackType = "Normal"
var CanMobility = true
var canAbility = true
#Magician Variables:
var doveCount:=1
@onready var dove := preload("res://Star Bullet.tscn")
@onready var magicHat:=preload("res://Magic Hat.tscn")
var currHat:Object=null
var invincible:=false
#Sword Variables
const DashSpeed = 3000
var dashDirection:=0
var dashTimer:=0.0
var swordDamage:=1.5
var dashDamage:=1.5
@export var dashVelocityPath:Curve
@onready var swordProjectile:= preload("res://Sword Projectile.tscn")
#Crystal Variables
@onready var crystalSpike:=preload("res://Crystal Spike.tscn")
@onready var crystalShot:=preload("res://Crystal Shot.tscn")
@onready var tallCrystalSpike:=preload("res://Tall Crystal Spike.tscn")
@onready var tallCrystalPlatform:=preload("res://Tall Crystal Platform.tscn")
@onready var crystalPlatform:=preload("res://Floating Crystal Platform.tscn")
#Curse Variables
@onready var cursePierce:=preload("res://Curse Pierce.tscn")
@onready var ghost:=preload("res://Ghost.tscn")
@onready var curseArea:=preload("res://Curse Area.tscn")
var currCurseDoll=null
var ghostMode:=false
var ghostPos:=Vector2(0,0)
#Mecha Variables
@onready var whip:=preload("res://Wire Whip.tscn")
@onready var spark:=preload("res://Spark.tscn")
@onready var smallElectricShot:=preload("res://Small Electric Shot.tscn")
@onready var bigElectricShot:=preload("res://Big Electric Shot.tscn")
var electricCharge:=0.0
var elecAttackMode:=0
#Disease Variables
@onready var syringe:=preload("res://Contaminated Syringe.tscn")
var marked:Object=null
var contaminated:=false


func _physics_process(delta: float) -> void:
	if contaminated:
		$"Contaminated Indicator/Node2D3".modulate.a-=delta/10
		$"Contaminated Indicator/RichTextLabel".text=str(int(ceil($"Contaminated Indicator/Node2D3".modulate.a*4)))
		if $"Contaminated Indicator/Node2D3".modulate.a<=0:
			contaminated=false
			$"Contaminated Indicator".visible=false
	
	
	if marked!=null:
		$"Mark Indicator".position=marked.position+Vector2(0,-300)-position
		$"Mark Indicator".modulate.a-=delta*0.1
	else:
		$"Mark Indicator".visible=false
	if $"Mark Indicator".modulate.a<=0:
		$"Mark Indicator".visible=false
		marked=null
	if characters[characterIndex]!="Curse":
		curse=max(0,curse-delta*1.5)
	if characters[characterIndex]=="Mecha":
		$Sprites.modulate=Color(0.1+electricCharge*0.8,0.1+electricCharge*0.8,0.1,$Sprites.modulate.a)
		electricCharge=min(1,electricCharge+delta*0.15)
		if charge>=1.0 and elecAttackMode<=1 and electricCharge>0.3:
			charge-=0.5+0.1*elecAttackMode
			elecAttackMode+=1
			electricCharge-=0.3
	else:
		$Sprites.modulate=Color(1,1,1,$Sprites.modulate.a)
		electricCharge=max(0,electricCharge-delta*0.1)
	if charge>=0.7:
		$Node2D.visible=true
	else:
		$Node2D.visible=false
	if charging:
		charge=min(charge+delta,1)
	if not is_on_floor():
		if Input.is_action_pressed(&"ui_up") and velocity.y <=-200:
			velocity += get_gravity() * delta * 2.05
		else:
			velocity += get_gravity() * delta *5
	if is_on_floor():
		velocity.y=min(velocity.y,0)
	
	if Input.is_action_pressed(&"ui_up") and is_on_floor():
			velocity.y = JUMP_VELOCITY

	var direction := Input.get_axis("ui_left", "ui_right")
	

	if dashTimer>0:

		velocity=Vector2(DashSpeed*dashDirection,0)#*dashVelocityPath.sample(dashTimer)
		dashTimer=max(0,dashTimer-delta*3)
		

	if direction and dashTimer<0.3:
		velocity.x = direction * SPEED *(1+electricCharge*0.5)
		$Sprites.scale.x=direction
		
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	$FirePoint.position.x=40*$Sprites.scale.x
	$RayCast2D.position.x=128*$Sprites.scale.x
	move_and_slide()


func _input(_event: InputEvent) -> void:
	var switchDirection:=int(Input.get_axis("Q", "E"))
	if switchDirection:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=(characterIndex+switchDirection)%characters.size()
		$Sprites.get_child(characterIndex).visible=true
	
	if Input.is_action_just_pressed(&"1") and characters.size()>=1:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=0
		$Sprites.get_child(characterIndex).visible=true
		
	if Input.is_action_just_pressed(&"2") and characters.size()>=2:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=1
		$Sprites.get_child(characterIndex).visible=true
	if Input.is_action_just_pressed(&"3") and characters.size()>=3:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=2
		$Sprites.get_child(characterIndex).visible=true
		
		
	if Input.is_action_just_pressed(&"4") and characters.size()>=4:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=3
		$Sprites.get_child(characterIndex).visible=true
		
	if Input.is_action_just_pressed(&"5") and characters.size()>=5:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=4
		$Sprites.get_child(characterIndex).visible=true
	if Input.is_action_just_pressed(&"6") and characters.size()>=6:
		$Sprites.get_child(characterIndex).visible=false
		characterIndex=5
		$Sprites.get_child(characterIndex).visible=true
		
	if Input.is_action_pressed("look_up"):
		LookingUp = true

		
	if Input.is_action_just_released("look_up"):
		LookingUp = false
		
	if Input.is_action_pressed("look_down") and not is_on_floor():
		LookingDown = true

		
	if Input.is_action_just_released("look_down"):
		LookingDown = false


	if Input.is_action_just_pressed("attack") and CanAttack:
		charging=true
		
	if Input.is_action_just_released("attack") and CanAttack:
		charging=false
		if charge <= 0.5:
			attack()
		elif charge >= 0.7 and !(LookingDown or LookingUp):
			chargeAttack()
		else:
			pass
		charge=0
	if Input.is_action_just_pressed("mobility") and CanMobility:
		mobility()
	
	if Input.is_action_just_pressed("ability") and canAbility:
		ability()
	
func attack():
	CanAttack = false
	$"Attack Hitbox/CollisionShape2D2".disabled = false
	AttackType = "Normal"
	match characters[characterIndex]:
		"Magician":
			if doveCount>=1:
				var newDove:=dove.instantiate()
				get_tree().current_scene.add_child(newDove)
				newDove.position=$FirePoint.global_position
				newDove.get_child(0).rotation=(-PI/2+(PI/2)* $Sprites.scale.x)
				doveCount-=1
		"Sword":
			$"Normal Sword".visible=true
			$"Normal Sword".monitoring=true
			$"Normal Sword".scale.x=$Sprites.scale.x
			await get_tree().create_timer(0.3).timeout
			$"Normal Sword".visible=false
			$"Normal Sword".monitoring=false
		

		"Crystal":
			if $RayCast2D.is_colliding():
				var newSpike:=crystalSpike.instantiate()
				get_tree().current_scene.add_child(newSpike)
				newSpike.position=$RayCast2D.global_position
				newSpike.scale.x=$Sprites.scale.x
			else:
				for i in range(3):
					var newCrystalShot:=crystalShot.instantiate()
					get_tree().current_scene.add_child(newCrystalShot)
					newCrystalShot.position=global_position+Vector2(100,0).rotated(-2*PI/3+(PI/2)* $Sprites.scale.x+PI/6*i)
					newCrystalShot.rotation=(-2*PI/3+(PI/2)* $Sprites.scale.x+PI/6*i)
		
		"Curse":
			var newCursePierce:=cursePierce.instantiate()
			get_tree().current_scene.add_child(newCursePierce)
			newCursePierce.position=$FirePoint.global_position
			newCursePierce.direction=$Sprites.scale.x
			take_curse(1.5)
		"Mecha":
			var newWhip :=whip.instantiate()
			add_child(newWhip)
			newWhip.charge=electricCharge
			newWhip.scale.x=$Sprites.scale.x
		"Disease":
			var newSyringe:=syringe.instantiate()
			get_tree().current_scene.add_child(newSyringe)
			newSyringe.position=position
			newSyringe.scale.x=$Sprites.scale.x
	await get_tree().create_timer(0.2).timeout
	$"Attack Hitbox/CollisionShape2D2".disabled = true
	await get_tree().create_timer(0.4).timeout
	CanAttack = true

func chargeAttack():
	CanAttack = false
	$"Attack Hitbox/CollisionShape2D2".disabled = false
	AttackType = "Charge"
	
	match characters[characterIndex]:
		"Sword":
			$"Normal Sword".visible=true
			$"Normal Sword".monitoring=true
			$"Normal Sword".scale.x=$Sprites.scale.x
			var newSwordProjectile:=swordProjectile.instantiate()
			get_tree().current_scene.add_child(newSwordProjectile)
			newSwordProjectile.position=position
			newSwordProjectile.scale.x=$Sprites.scale.x
			newSwordProjectile.direction=$Sprites.scale.x
			await get_tree().create_timer(0.3).timeout
			$"Normal Sword".visible=false
			$"Normal Sword".monitoring=false

		"Crystal":
			if $RayCast2D.is_colliding():
				var newSpike:=tallCrystalSpike.instantiate()
				get_tree().current_scene.add_child(newSpike)
				newSpike.position=$RayCast2D.global_position

			else:
				var newCrystalShot:=crystalShot.instantiate()
				get_tree().current_scene.add_child(newCrystalShot)
				newCrystalShot.position=global_position+Vector2(100,0).rotated(-PI/2+(PI/2)* $Sprites.scale.x)
				newCrystalShot.rotation=(-PI/2+(PI/2)* $Sprites.scale.x)
				newCrystalShot.scale=Vector2(1,2)
		
		
		
		"Curse":
			var enemyList:Array=get_tree().current_scene.enemyList
			var totalCurse:=0.0
			totalCurse+=curse
			for i in enemyList:
				if i!=null:
					totalCurse+=i.curse
			while totalCurse>0.1:
				totalCurse=max(0,totalCurse-0.5)
				curse=max(0,curse-curse/totalCurse/0.5)
				$Camera2D/Line2D/Line2D4.points[1].x=-100+curse/maxHealth*200
				var newGhost:=ghost.instantiate()
				get_tree().current_scene.add_child(newGhost)
				newGhost.position=position
				newGhost.angle=randf_range(0,PI*2)
				var valid=false
				while !valid:
					var target=TargetCursedEnemy()
					if target!=null:
						if position.distance_to(target.position)<1000:

							newGhost.target=target
							valid=true
					else:
						valid=true
				await get_tree().create_timer(0.1).timeout
		"Mecha":
			
			match elecAttackMode:
				0:
					for i in range(8):
						var newSpark=spark.instantiate()
						get_tree().current_scene.add_child(newSpark)
						newSpark.position=global_position
						newSpark.rotation=deg_to_rad(i*45)
				1:
					var smallShot=smallElectricShot.instantiate()
					get_tree().current_scene.add_child(smallShot)
					smallShot.position=global_position
					smallShot.scale.x=$Sprites.scale.x
				2:
					var bigShot=bigElectricShot.instantiate()
					get_tree().current_scene.add_child(bigShot)
					bigShot.position=global_position
					bigShot.scale.x=$Sprites.scale.x
			elecAttackMode=0
		"Disease":
			contaminated=true
			$"Contaminated Indicator".visible=true
			$"Contaminated Indicator/Node2D3".modulate.a=1
			
	await get_tree().create_timer(0.4).timeout
	$"Attack Hitbox/CollisionShape2D2".disabled = true
	await get_tree().create_timer(0.6).timeout
	CanAttack = true


func ability():
	match characters[characterIndex]:
		pass

func mobility():
	CanMobility = false
	match characters[characterIndex]:
		"Magician":
			if currHat==null:
				currHat=magicHat.instantiate()
				get_tree().current_scene.add_child(currHat)
				currHat.position=$FirePoint.global_position
				if !LookingUp:
					currHat.direction=Vector2($Sprites.scale.x,0)
				else:
					currHat.direction=Vector2(0,-0.66)
			else:
				if !currHat.insideWall:
					position=currHat.position
				else:
					position=currHat.lastValidPos
				currHat.call_deferred("queue_free")
		"Sword":
			invincible=true
			$"Dash Sword".visible=true
			$"Dash Sword".monitoring=true
			dashTimer=1.0
			dashDirection= $Sprites.scale.x
			$"Dash Sword".scale.x=dashDirection
			await get_tree().create_timer(0.3).timeout
			$"Dash Sword".visible=false
			$"Dash Sword".monitoring=false
			invincible=false
		"Crystal":
			if is_on_floor():
				var newCrystalPillar:=tallCrystalPlatform.instantiate()
				get_tree().current_scene.add_child(newCrystalPillar)
				newCrystalPillar.position=position+Vector2(0,128)
			else:
				var newCrystalPlatform:=crystalPlatform.instantiate()
				get_tree().current_scene.add_child(newCrystalPlatform)
				newCrystalPlatform.position=position+Vector2(0,128)
		"Curse":
			if !ghostMode:
				set_collision_layer_value(1,false)
				set_collision_mask_value(1,false)
				set_collision_layer_value(2,false)
				set_collision_mask_value(2,false)
				
				ghostPos=position
				ghostMode=true
				$Sprites.modulate.a=0.5
				var newDoll:=curseArea.instantiate()
				get_tree().current_scene.add_child(newDoll)
				newDoll.position=position
				currCurseDoll=newDoll
			else:
				set_collision_layer_value(1,true)
				set_collision_mask_value(1,true)
				set_collision_layer_value(2,true)
				set_collision_mask_value(2,true)
				position=ghostPos
				ghostMode=false
				$Sprites.modulate.a=1
				currCurseDoll.call_deferred("queue_free")
		"Disease":
			if marked==null:
				$"Disease Jab".visible=true
				$"Disease Jab".monitoring=true
				$"Disease Jab".scale.x=$Sprites.scale.x
				await get_tree().create_timer(0.3).timeout
				$"Disease Jab".visible=false
				$"Disease Jab".monitoring=false
				$"Mark Indicator".visible=true
				$"Mark Indicator".modulate.a=1
			else:
				var markPos=marked.position
				marked.position=position
				position=markPos
	await get_tree().create_timer(0.4).timeout
	CanMobility = true

func TakeDamage(Damage):
	Health -= Damage
	if Health <= 0:
		get_tree().call_deferred(&"reload_current_scene")
	get_tree().current_scene.take_damage()


func collect_bird():
	doveCount+=1

func _on_dash_sword_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(dashDamage)


func _on_normal_sword_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(swordDamage)

func take_curse(curseDamage):
	curse+=curseDamage
	$Camera2D/Line2D/Line2D4.points[1].x=-100+curse/maxHealth*200
	if curse>Health:
		get_tree().call_deferred(&"reload_current_scene")

func TargetCursedEnemy():
	var enemyList:Array=get_tree().current_scene.enemyList
	var target = enemyList.pick_random()
	if target != null:
		if target.is_in_group("PlayerCursed"):
			return target
		else:
			return null



func _on_ghost_hit_box_body_exited(body: Node2D) -> void:
	if body.is_in_group("Solid Wall") and ghostMode:
		set_collision_layer_value(1,true)
		set_collision_mask_value(1,true)
		set_collision_layer_value(2,true)
		set_collision_mask_value(2,true)
		ghostMode=false
		$Sprites.modulate.a=1
		currCurseDoll.call_deferred("queue_free")
	elif contaminated:
		body.add_contaminate(4*$"Contaminated Indicator/Node2D3".modulate.a)




func hook_latched():
	pass


func _on_disease_jab_body_entered(body: Node2D) -> void:
	if body.is_in_group("Enemy"):
		body.take_damage(1)
		marked=body
		$"Mark Indicator".visible=true
		$"Mark Indicator".modulate.a=1
