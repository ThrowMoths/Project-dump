extends Area2D

var health:=10.0
var maxHealth:=10.0
var type:="1"
var invincibility:=0.0
var Player:Object=null
var velocity:Vector2=Vector2.ZERO
var knockbackVelocity:Vector2=Vector2.ZERO
var moveVelocity:Vector2=Vector2.ZERO
var knockbackMulti:=1.0
var deathEmitted=false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	match type:
		"1":
			modulate=Color(1,0,0)
		"2":
			modulate=Color(0,1,0)
		"3":
			modulate=Color(0,0,1)
func _physics_process(delta: float) -> void:
	invincibility-=delta
	
	if invincibility>=0:
		modulate.a=0.6+0.4*int(floori(invincibility*10)%3>1)
	else:
		modulate.a=1
	


	$"Health Outline/Health Lerp".set_point_position(1,Vector2(lerp($"Health Outline/Health Lerp".get_point_position(1).x, -100+health/maxHealth*200,3*delta),0))
	modulate=lerp(modulate,Color(1,1,1),delta*2)
	
	
	
	
	
	Player = get_tree().current_scene.Player
	
	
	#moveVelocity.x =(Direction * SPEED*(1-0.15*contaminationLevel))
	velocity=knockbackVelocity+moveVelocity
	knockbackVelocity= knockbackVelocity.move_toward(Vector2(0,0),3500*delta)
	
	position+=velocity*delta
	
	
	
	

func take_damage(Damage):
	if invincibility<=0:
		health -= Damage
		emit_signal("hit")
	if health <= 0 and !deathEmitted:
		get_tree().current_scene.enemy_died()
		
		call_deferred("queue_free")
		deathEmitted=true

		
	modulate=Color(1,0,0)
	
	$"Health Outline/Health".set_point_position(1,Vector2(-100+health/maxHealth*200,0))
func take_knockback(vector):
	knockbackVelocity=vector*knockbackMulti
	moveVelocity.y =move_toward(moveVelocity.y,vector.y*knockbackMulti,vector.length()*knockbackMulti)
