extends Area2D

var angle:=0.0
var speed:=1000.0
var type:="2"
var damage=3
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Sprite2D.rotation=angle
	match type:
		
		"1":
			modulate=Color(1,0,0)
		"2":
			modulate=Color(0,1,0)
		"3":
			modulate=Color(0,0,1)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position+=Vector2(speed,0).rotated(angle)*delta


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Enemy"):
		if area.type==type:
			area.take_damage(damage)
		call_deferred("queue_free")
