extends Node

var scores:=[0,0]
var upgrades:=[[],[]]


func add_score(player):
	scores[player-1]+=1
	if scores[player-1]>=6:
		print("PLAYER ",player," WINS")
		scores=[0,0]
		upgrades=[[],[]]
