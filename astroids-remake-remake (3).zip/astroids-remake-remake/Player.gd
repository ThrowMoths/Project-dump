extends CharacterBody2D
var maxMoveSpeed:=1000.0
var turnSpeed:=2000.0
var moveAngle:=0.0
var mode:="Normal"
var dashCooldown:=0.0
var dashDirection:=0.0
var dashSpeed:=3000.0
var dashDuration:=0.4
var parryDuration:=0.5
var invincible:=false

@onready var sword:=preload("res://sword.tscn")
func _process(delta: float) -> void:
	dashCooldown-=delta
	
	if Input.is_action_just_pressed("X"):
		dash()
	if Input.is_action_just_pressed("C"):
		mode="Parrying"
		$Parry.monitoring=true
		
		colorTween($Parry,Color(1,1,1),parryDuration,Color(1,1,1,0))
		colorTween($"Line2D/Player Fill",Color(1,1,1),parryDuration,Color(1,1,1,0))
		await get_tree().create_timer(dashDuration).timeout
		mode="Normal"
		$Parry.monitoring=false
	
	if velocity.length()>0:
		$Line2D.rotation=Vector2.ZERO.angle_to_point(velocity)
		$Parry.rotation=Vector2.ZERO.angle_to_point(velocity)
	#elif mode=="Parrying":
	#	$Line2D.rotation=moveAngle
	#	$Area2D.rotation=moveAngle
	#moveAngle=get_angle_to(get_global_mouse_position())
	var moveDist:float
	
	var moveDir:=Vector2(Input.get_axis("ui_left","ui_right"),Input.get_axis("ui_up","ui_down"))
	moveAngle=Vector2(0,0).angle_to_point(moveDir)
	moveDist=moveDir.normalized().length()
	
	if false:
	#if true:
		moveDist=get_parent().stickDist
		moveAngle=get_parent().stickAngle
	if moveDist>0 and mode=="Normal":
		velocity=velocity.move_toward(Vector2(maxMoveSpeed,0).rotated(moveAngle),turnSpeed*delta*1.5*moveDist)
	elif mode=="Dashing":
		velocity=Vector2(dashSpeed,0).rotated(dashDirection)
	else:
		velocity=velocity.move_toward(Vector2.ZERO,3000.0*delta)
	move_and_slide()

	if position.x>2700:
		position.x=-2700
	elif position.x<-2700:
		position.x=2700
	
	if position.y>1350:
		position.y=-1350
	elif position.y<-1350:
		position.y=1350
	
	
func dash():
	if dashCooldown<=0 and mode=="Normal":
		dashCooldown=1.0
		mode="Dashing"
		
		dashDirection=$Line2D.rotation
		colorTween($Line2D,Color(1,0,0),dashDuration)
		await get_tree().create_timer(dashDuration).timeout
		
		
		velocity=Vector2(2500,0).rotated(dashDirection)
		mode="Normal"

func colorTween(object,color,duration,endColour:=Color(1,1,1)):
	object.modulate=color
	var newTween=get_tree().create_tween()
	newTween.tween_property(object,"modulate",endColour,duration)

func create(object,position:=Vector2(-999999,-999999)):
	var newObject=object.instantiate()
	get_tree().current_scene.add_child(newObject)
	newObject.position=position
	return newObject

func take_damage():
	pass
