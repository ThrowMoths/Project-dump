extends CharacterBody2D


const SPEED = 1200.0
const JUMP_VELOCITY = -400.0
@export var player:=1
var mode:="Normal"
var dashCooldown:=0.0
var dashDirection:=0.0
var dashSpeed:=3000.0
var dashDuration:=0.2
var holdingSword:=true
var swordCooldown:=1.8
var health:=100.0
var maxHealth:=100.0
var invincibility:=2.0
var damage:=30.0
var thrownDamage:=30.0
@onready var sword:=preload("res://sword.tscn")

func _physics_process(delta: float) -> void:
	$"Weapon Pivot/Held Sword".visible=holdingSword
	invincibility-=delta
	if invincibility>0:
		modulate.a=1-0.5*int(floori(invincibility*100)%20>10)
	else:
		modulate.a=1
	dashCooldown-=delta
	var direction :Vector2
#	var attackDirection:Vector2
#	var attackReleased:bool
	if player==1:
		direction= Vector2(Input.get_axis("A", "D"),Input.get_axis("W", "S")).normalized()
		
		#attackDirection= Vector2(Input.get_axis("Left Arrow", "Right Arrow"),Input.get_axis("Up Arrow", "Down Arrow")).normalized()
		#attackReleased=Input.is_action_just_released("Up Arrow")or Input.is_action_just_released("Down Arrow")or Input.is_action_just_released("Left Arrow")or Input.is_action_just_released("Right Arrow")
	elif player==2:
		direction=  Vector2(Input.get_axis("Left Arrow", "Right Arrow"),Input.get_axis("Up Arrow", "Down Arrow")).normalized()
		
		#attackDirection= Vector2(Input.get_axis("Left Arrow 2", "Right Arrow 2"),Input.get_axis("Up Arrow 2", "Down Arrow 2")).normalized()
		#attackReleased=Input.is_action_just_released("Up Arrow 2")or Input.is_action_just_released("Down Arrow 2")or Input.is_action_just_released("Left Arrow 2")or Input.is_action_just_released("Right Arrow 2")
		
	if direction:
		$"Weapon Pivot".rotation=Vector2.ZERO.angle_to_point(direction)

	if (Input.is_action_just_pressed("ui_accept") and player==1) or (Input.is_action_just_pressed("J") and player==2):
		dash() 
	if (Input.is_action_just_pressed("C") and player==1) or (Input.is_action_just_pressed("K") and player==2):
		throw() 
#	elif attackReleased:
#		attack_ability()
	if direction and mode=="Normal":
		velocity = direction * SPEED
	
	elif mode=="Dashing":
		velocity=Vector2(dashSpeed,0).rotated(dashDirection)
	
	else:
		velocity *=0
	

	
	move_and_slide()
	if position.x>2700:
		position.x=-2700
	elif position.x<-2700:
		position.x=2700
	
	if position.y>1500:
		position.y=-1500
	elif position.y<-1500:
		position.y=1500
	
func attack_ability():
	dash()

func throw():
	if holdingSword:
		holdingSword=false
		var newSword = create(sword,$"Weapon Pivot/Held Sword".global_position)
		newSword.angle=$"Weapon Pivot".rotation
		newSword.player=player
		newSword.damage=thrownDamage
		await get_tree().create_timer(swordCooldown).timeout
		holdingSword=true

func create(object,objPosition:=Vector2(-999999,-999999)):
	var newObject=object.instantiate()
	get_tree().current_scene.add_child(newObject)
	newObject.position=objPosition
	return newObject

func dash():
	if dashCooldown<=0 and mode=="Normal":
		dashCooldown=1.0
		mode="Dashing"
		
		dashDirection=$"Weapon Pivot".rotation
		colorTween($Line2D,Color(1,0,0),dashDuration)
		await get_tree().create_timer(dashDuration).timeout
		
		
		velocity=Vector2(2500,0).rotated(dashDirection)
		mode="Normal"
func colorTween(object,color,duration,endColour:=Color(1,1,1)):
	object.modulate=color
	var newTween=get_tree().create_tween()
	newTween.tween_property(object,"modulate",endColour,duration)


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		body.take_damage(damage)

func take_damage(damage):
	if invincibility<=0 and mode=="Normal":
		health-=damage
		invincibility=1.0
		get_tree().current_scene.player_damaged(player,health,maxHealth)
