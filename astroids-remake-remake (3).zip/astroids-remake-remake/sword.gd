extends Area2D

var angle:=0.0
var speed:=4000.0
var player:=3
var damage:=20.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	rotation=angle
	await get_tree().create_timer(1.8).timeout
	call_deferred("queue_free")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position+=Vector2(speed,0).rotated(angle)*delta
	speed=move_toward(speed,0,8000*delta)
	if position.x>2200:
		position.x=-2200
	elif position.x<-2200:
		position.x=2200
	
	if position.y>1200:
		position.y=-1200
	elif position.y<-1200:
		position.y=1200
		
		


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player") :#and speed>100:
		if body.player!=player:
			body.take_damage(damage)
