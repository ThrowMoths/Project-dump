extends Area2D

var radius:=400.0
var speed:=800.0
var speedMulti:=1.0
var angle:=0.0
@onready var asteroid:=preload("res://Asteroid.tscn")

func _ready() -> void:
	await get_tree().process_frame
	$CollisionShape2D.shape.radius=radius
	for i in range(20):
		$Line2D.set_point_position(i,Vector2(radius*randf_range(0.8,1.2),0).rotated(2*PI/20*i))
		$Polygon2D.polygon[i]=$Line2D.get_point_position(i)
	angle=randf_range(0,2*PI)

func _physics_process(delta: float) -> void:
	speedMulti=move_toward(speedMulti,1,delta)
	modulate=modulate.lerp(Color(1,1,1),delta*2)
	position+=Vector2(speed,0).rotated(angle)*delta*speedMulti
	$Polygon2D.modulate.a=move_toward($Polygon2D.modulate.a,0,delta)
	if position.x>2500:
		position.x=-2500
	elif position.x<-2500:
		position.x=2500
	
	if position.y>1600:
		position.y=-1600
	elif position.y<-1600:
		position.y=1600
func explode():
	if radius>150:
		for i in range(2):
			var newAsteroid = create(asteroid,position)
			newAsteroid.radius=radius/2
			newAsteroid.angle=randf_range(0,2*PI)
			newAsteroid.speedMulti=2
	call_deferred("queue_free")
func deflect(direction):
	print("hi")
	angle=direction
	$Polygon2D.modulate.a=1
	speedMulti=3
func create(object,position:=Vector2(-999999,-999999)):
	var newObject=object.instantiate()
	get_tree().current_scene.add_child(newObject)
	newObject.position=position
	return newObject

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		if body.mode=="Dashing" and modulate.g>=0.9:
			explode()
		elif body.mode=="Normal" and !body.invincible:
			body.take_damage()
