extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	get_tree().paused=true
	for i in range(Score.scores[0]):
		$"Score Counter".get_child(-i-1).default_color=Color("2779d4")
	
	for i in range(Score.scores[1]):
		$"Score Counter".get_child(i).default_color=Color("c12b4d")


func player_damaged(player,health,maxHealth):
	var target:Object
	if player==1:
		target=$"Player 1 Health/Line2D/Health"
	elif player==2:
		target=$"Player 2 Health/Line2D/Health"
	
	target.set_point_position(0,Vector2(-500*health/maxHealth,0))
	target.set_point_position(1,Vector2(500*health/maxHealth,0))
	
	if health<=0:
		player_lost(player)

func player_lost(player):
	Score.add_score(3-player)
	
	get_tree().call_deferred("reload_current_scene")
