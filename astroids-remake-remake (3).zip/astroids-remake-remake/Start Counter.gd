extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(1,true).timeout
	$Polygon2D/Light.default_color=Color("ffd182")
	$RichTextLabel.text="[center]II"
	await get_tree().create_timer(1,true).timeout
	$Polygon2D/Light.default_color=Color("48ff8b")
	$RichTextLabel.text="[center]I"
	await get_tree().create_timer(1,true).timeout
	$RichTextLabel.text="[center]!¡"
	for i in range(5):
		$Polygon2D/Light.default_color=Color("ffd182")
		await get_tree().create_timer(0.1,true).timeout
		$Polygon2D/Light.default_color=Color("ff5d4f")
		await get_tree().create_timer(0.1,true).timeout
	hide()
	get_tree().paused=false
