extends CharacterBody2D


const SPEED = 800.0
const JUMP_VELOCITY = -400.0
var shiftMode="1"
@onready var testAttack:=preload("res://Player Attack.tscn")
func _ready() -> void:
	switch_mode("1")

func _physics_process(delta: float) -> void:

	var direction := Vector2(Input.get_axis("ui_left", "ui_right"),Input.get_axis("ui_up","ui_down")).normalized()
	if direction:
		velocity = direction * SPEED
	else:
		velocity *=0

	move_and_slide()

	if Input.is_action_just_pressed("Shift"):
		match shiftMode:
			"1":
				switch_mode("2")
			"2":
				switch_mode("3")
			"3":
				switch_mode("1")
	if Input.is_action_just_pressed("Left Click"):
		attack()
		
func switch_mode(newMode):
	match newMode:
		"1":
			shiftMode="1"
			$Sprite2D.texture=load("res://icon.svg")
			
			modulate=Color(1,0,0)
		"2":
			shiftMode="2"
			$Sprite2D.texture=load("res://icon.svg")
			
			modulate=Color(0,1,0)
		"3":
			shiftMode="3"
			$Sprite2D.texture=load("res://icon.svg")
			modulate=Color(0,0,1)
func attack():
	match shiftMode:
		"1":
			var newAttack:=testAttack.instantiate()
			newAttack.angle=get_angle_to(get_global_mouse_position())
			newAttack.type=shiftMode
			get_tree().current_scene.add_child(newAttack)
			newAttack.position=position
			
		"2":
			var newAttack:=testAttack.instantiate()
			newAttack.angle=get_angle_to(get_global_mouse_position())
			newAttack.type=shiftMode
			get_tree().current_scene.add_child(newAttack)
			newAttack.position=position
			
			
		"3":
			var newAttack:=testAttack.instantiate()
			newAttack.angle=get_angle_to(get_global_mouse_position())
			newAttack.type=shiftMode
			get_tree().current_scene.add_child(newAttack)
			newAttack.position=position
			
func ability():
	match shiftMode:
		"1":
			pass
		"2":
			pass
		"3":
			pass
