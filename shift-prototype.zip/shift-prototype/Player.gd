extends CharacterBody2D


const SPEED = 800.0
const JUMP_VELOCITY = -400.0


func _physics_process(delta: float) -> void:

	var direction := Vector2(Input.get_axis("ui_left", "ui_right"),Input.get_axis("ui_up","ui_down")).normalized()
	if direction:
		velocity = direction * SPEED
	else:
		velocity *=0

	move_and_slide()
