extends Polygon2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for i in range(7):
		for ii in range(7):
			get_child(i).get_child(ii).visible=false
func room_revealed(coords,type):
	get_child(coords.y).get_child(coords.x).visible=true
	match type:
		"Start":
			get_child(coords.y).get_child(coords.x).modulate=Color(0,1,0)
		"Exit!":
			get_child(coords.y).get_child(coords.x).modulate=Color(1,0,0)
		"Gifts":
			get_child(coords.y).get_child(coords.x).modulate=Color(1,1,0)
