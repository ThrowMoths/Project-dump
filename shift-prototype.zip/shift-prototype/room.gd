extends Node2D

var coords:=Vector2i(0,0)
var type:="Blank"
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().process_frame
	generate_doors()
	if type=="Exit!":
		z_index=3
		modulate=Color(1,0,0)
	if type=="Gifts":
		z_index=3
		modulate=Color(1,1,0)
	if type=="Start":
		z_index=3
		modulate=Color(0,1,0)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func generate_doors():
	var grid:Array=get_tree().current_scene.grid

	if coords.x<6:
		if grid[coords.y][coords.x+1]!="Empty":
			$"Full Right".queue_free()
		else:
			$"Part Right".queue_free()
	if coords.x>0:
		if grid[coords.y][coords.x-1]!="Empty":
			$"Full Left".queue_free()
		else:
			$"Part Left".queue_free()
	if coords.y<6:
		if grid[coords.y+1][coords.x]!="Empty":
			$"Full Down".queue_free()
		else:
			$"Part Down".queue_free()
	if coords.y>0:
		if grid[coords.y-1][coords.x]!="Empty":
			$"Full Up".queue_free()
		else:
			$"Part Up".queue_free()




func _on_right_trigger_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		entered()

func _on_left_trigger_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		entered()

func _on_down_trigger_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		entered()

func _on_up_trigger_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player"):
		entered()
func entered():
	print("hi")
	get_tree().current_scene.room_entered(self)
